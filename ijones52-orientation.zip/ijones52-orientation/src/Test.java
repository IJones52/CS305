/*
* TCSS 305 � Winter 2020
* Assignment 1 � Orientation
*/

/**
* This program just holds some methods that fulfill the requirements of Programming Assignment 1
* It features a basic method that will print hello world and a method to find the average red value out of a set of colors.
* 
* @author Ismael Jones
* @version 1/9/2020 
*/

public class Test {
    
    //Just a blank constructor
    public Test() {}
    
    public void printHelloWorld() {
        System.out.println("Hello, World!");
    }
}
